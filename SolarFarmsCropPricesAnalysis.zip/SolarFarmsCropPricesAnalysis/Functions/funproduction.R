function(p){
     area      = funarea(p)     
     co        = sum(area[,1]*agmodel$YDCO,na.rm=TRUE)/1e6
     sb        = sum(area[,2]*agmodel$YDSB,na.rm=TRUE)/1e6
     wh        = sum(area[,3]*agmodel$YDWH,na.rm=TRUE)/1e6
     qs        = c(co,sb,wh)
     return(qs)}