function(p){
     qd        = fundemand(p)
     qd        = c(qd[1],qd[2]/(44/60)+qd[4],qd[3]/(11/60)+qd[4],qd[5])
     qs        = funproduction(p)
     qs        = c(qs[1],qs[2],qs[2],qs[3])
     output    = sum((qd-qs)^2)
     return(output)}