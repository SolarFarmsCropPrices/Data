function(p){
     area                = matrix(0,3105,3)
     returns             = funreturn(p)
     area[,1]            = areacons[,1]*apply(returns^ahelas[["CO"]],1,prod)
     area[,2]            = areacons[,2]*apply(returns^ahelas[["SB"]],1,prod)
     area[,3]            = areacons[,3]*apply(returns^ahelas[["WH"]],1,prod)
     area[is.na(area)]   = 0
     area                = area/rowSums(area)*maxarea
     area[is.na(area)]   = 0
     return(area)}
