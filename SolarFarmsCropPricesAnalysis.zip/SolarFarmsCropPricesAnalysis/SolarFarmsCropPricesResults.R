#==================================================================================================
# Title:                 Solar Farms and Crop Prices Results
# Author:                Jerome Dumortier
# Date:                  19 May 2025
#==================================================================================================
rm(list=ls())
library(ggplot2)
library(ggspatial)
library(openxlsx)
library(sf)
library(terra)
root                     = "D:/Research/Live Manuscripts/Solar Farms and Crop Prices"
setwd(paste(root,"/Analysis",sep=""))
load("SolarFarmsCropPricesResults.RData")
commodities              = data.frame(commodity=c("CO","SB","WH"),
                                      commodityname=c("Maize","Soybeans","Wheat"))
scenarios                = readWorkbook("SolarFarmsCropPrices.xlsx",sheet="SCENARIOS")
scenarios                = subset(scenarios,cost=="Base Cost" & land=="2.6 ha")
scenarios                = scenarios[c("scenario","countycap","oncropland","pv","cost")]
#--------------------------------------------------------------------------------------------------
# Changes in Commodity Prices
#--------------------------------------------------------------------------------------------------
prices                   = subset(prices,commodity %in% commodities$commodity)
dfbase                   = subset(prices,scenario=="Baseline",select=c("commodity","value"))
dfscen                   = subset(prices,scenario!="Baseline")
dfscen                   = merge(dfbase,dfscen,by=c("commodity"))
dfscen$change            = dfscen$value.y/dfscen$value.x-1
dfscen                   = dfscen[c("commodity","scenario","change")]
dfscen                   = merge(dfscen,commodities,by=c("commodity"))
#--------------------------------------------------------------------------------------------------
dfcore                   = subset(dfscen,scenario %in% scenarios$scenario)
dfcore                   = merge(dfcore,scenarios,by=c("scenario"))
#--------------------------------------------------------------------------------------------------
dfcore                   = subset(dfcore,commodity %in% c("CO","SB","WH"))
ggplot(dfcore,aes(y=change*100,fill=paste(countycap*100,"% Area Cap",sep=""),x=oncropland))+
     theme_bw()+geom_bar(stat="identity",position=position_dodge(),color="black")+
     facet_grid(vars(commodityname),vars(pv))+
     scale_fill_brewer(palette="Paired")+ylab("% Change from No Solar")+
     theme(legend.title=element_blank(),axis.title.x=element_blank(),legend.position="bottom",
           panel.grid=element_blank())
ggsave(paste(root,"/Manuscript/pricechange.pdf",sep=""),width=8,height=6)
#--------------------------------------------------------------------------------------------------
# Area Requirement and Area Use by State
#--------------------------------------------------------------------------------------------------
areareq                  = aggregate(area$value,FUN=sum,by=list(area$scenario))
colnames(areareq)        = c("scenario","value")
areareq$value            = areareq$value[which(areareq$scenario=="Baseline")]-areareq$value
#--------------------------------------------------------------------------------------------------
areabase                 = subset(area,scenario=="Baseline")
areascen                 = subset(area,scenario!="Baseline")
areascen                 = merge(areascen,areabase,by=c("fips"))
areascen$value           = areascen$value.y-areascen$value.x
states                   = readWorkbook("SolarFarmsCropPrices.xlsx",sheet="COUNTY")
areascen                 = merge(areascen,states,by=c("fips"))
areascen                 = aggregate(areascen$value,FUN=sum,
                                     by=list(areascen$statename,areascen$scenario.x))
colnames(areascen)       = c("state","scenario","value")
#--------------------------------------------------------------------------------------------------
soi                      = subset(areascen,scenario=="Baseline (25%) - 100% Cropland")
soi                      = soi[order(-soi$value),]
row.names(soi)           = NULL
soi                      = as.character(soi$state[1:5])
#--------------------------------------------------------------------------------------------------
df                       = subset(areascen,state %in% soi & scenario %in% scenarios$scenario)
df                       = merge(df,scenarios,by=c("scenario"))
ggplot(df,aes(x=oncropland,y=value/1000000,fill=paste(countycap*100,"% Area Cap",sep="")))+
     geom_bar(stat="identity",position=position_dodge(),color="black")+theme_bw()+
     scale_fill_brewer(palette="Paired")+ylab("in Million Ha")+
     facet_grid(vars(state),vars(pv))+
     theme(legend.title=element_blank(),axis.title.x=element_blank(),legend.position="bottom",
           panel.grid=element_blank())
ggsave(paste(root,"/Manuscript/areadifferencestate.pdf",sep=""),width=8,height=6)
#--------------------------------------------------------------------------------------------------
# Changes in Production
#--------------------------------------------------------------------------------------------------
dfbase                   = subset(production,scenario=="Baseline",select=c("commodity","value"))
dfscen                   = subset(production,scenario!="Baseline")
dfscen                   = merge(dfbase,dfscen,by=c("commodity"))
dfscen$change            = dfscen$value.y/dfscen$value.x-1
dfscen                   = dfscen[c("commodity","scenario","change")]
dfscen                   = merge(dfscen,commodities,by=c("commodity"))
#--------------------------------------------------------------------------------------------------
dfcore                   = subset(dfscen,scenario %in% scenarios$scenario)
dfcore                   = merge(dfcore,scenarios,by=c("scenario"))
#--------------------------------------------------------------------------------------------------
dfcore                   = subset(dfcore,commodity %in% c("CO","SB","WH"))
ggplot(dfcore,aes(y=change*100,fill=paste(countycap*100,"% Area Cap",sep=""),x=oncropland))+
     theme_bw()+geom_bar(stat="identity",position=position_dodge(),color="black")+
     facet_grid(vars(commodityname),vars(pv))+
     scale_fill_brewer(palette="Paired")+ylab("% Change from No Solar")+
     theme(legend.title=element_blank(),axis.title.x=element_blank(),legend.position="bottom",
           panel.grid=element_blank())
ggsave(paste(root,"/Manuscript/productionchange.pdf",sep=""),width=8,height=6)
#--------------------------------------------------------------------------------------------------
rm(list=setdiff(ls(),c("farmrevenue","core","root")))
#--------------------------------------------------------------------------------------------------
# Net Return Change
#--------------------------------------------------------------------------------------------------
farmrevenue              = farmrevenue[!is.nan(farmrevenue$value),]
revbase                  = subset(farmrevenue,scenario=="Baseline",select=c("fips","value"))
revscen                  = subset(farmrevenue,scenario!="Baseline")
revscen                  = merge(revscen,revbase,by=c("fips"))
revscen$value            = revscen$value.x/revscen$value.y-1
df                       = revscen[c("fips","scenario","value")]
dfbase                   = subset(df,scenario=="Baseline (25%) - High Cropland")
dfbase$value             = dfbase$value*100
dfhipv                   = subset(df,scenario=="High PV (25%) - High Cropland")
dfhipv$value             = dfhipv$value*100
#--------------------------------------------------------------------------------------------------
soi                      = c("24","19","10","39","42","31","01","05","48","21","13","55","29","51",
                             "47","22","36","26","12","17","27","18","25","20","50","09","34","11",
                             "37","38","45","28","46","40","54","23","33","44")
soi                      = as.numeric(soi)
labels                   = c("Below 1%","1%-2%","2%-3%","3%-4%","4%-5%",
                             "5%-7.5%","7.5%-10%","Above 10%")
breaks                   = c(0,1,2,3,4,5,7.5,10,100)
my_colors                = colorRampPalette(RColorBrewer::brewer.pal(9,"YlGnBu"))(8)
#--------------------------------------------------------------------------------------------------
counties                 = read_sf(dsn=paste(root,"/GIS/Census",sep=""),layer="counties")
states                   = read_sf(dsn=paste(root,"/GIS/Census",sep=""),layer="states")
counties                 = subset(counties,statefips %in% soi)
states                   = subset(states,statefips %in% soi)
#--------------------------------------------------------------------------------------------------
tempcounties             = counties
tempcounties             = merge(tempcounties,rbind(dfbase,dfhipv),by="fips")
#--------------------------------------------------------------------------------------------------
ggplot()+
     geom_sf(data=tempcounties,aes(fill=cut(value,breaks=breaks,include.lowest=TRUE)),linetype=0)+
     theme_bw()+scale_fill_manual(values=my_colors,labels=labels)+
     geom_sf(data=states,colour="black",linetype=1,alpha=0)+coord_sf(crs="+init=epsg:26978")+
     theme(legend.position="bottom")+facet_wrap(vars(scenario),ncol=2)+
     guides(fill=guide_legend(title="Revenue Change"))
ggsave(paste(root,"/Manuscript/revenuemap.pdf",sep=""),width=9,height=6)
#==================================================================================================
# End of File
#==================================================================================================