function(p){
     pco            = p[1]
     psb            = p[2]
     psm            = p[3]
     pso            = p[4]
     pwh            = p[5]
     cofood         = pm$COFOOD+pm$FOCOCO*log(pco)
     cofeed         = pm$COFEED+pm$FECOCO*log(pco)+pm$FECOSB*log(psb)
     coexpo         = pm$COEXPO+pm$FXCOCO*log(pco)+pm$FXCOWH*log(pwh)
     whfood         = pm$WHFOOD+pm$FOWHWH*log(pwh)
     whfeed         = pm$WHFEED+pm$FEWHWH*log(pwh)+pm$FEWHCO*log(pco)
     whexpo         = pm$WHEXPO+pm$FXWHSB*log(psb)+pm$FXWHCO*log(pco)+pm$FXWHWH*log(pwh)
     corn           = exp(cofood)*pm$pop+exp(cofeed)*pm$gcau+exp(coexpo)+pm$ethanol
     wheat          = exp(whfood)*pm$pop+exp(whfeed)*pm$gcau+exp(whexpo)
     smfeed         = pm$SMFEED+pm$FESMSM*log(psm)+pm$FESMCO*log(pco)
     smexpo         = pm$SMEXPO+pm$FXSMSM*log(psm)
     sbmeal         = exp(smfeed)*pm$hpau+exp(smexpo)
     sofood         = pm$SOFOOD+pm$FOSOSO*log(pso)
     soexpo         = pm$SOEXPO+pm$FXSOSO*log(pso)
     sboil          = exp(sofood)*pm$pop+exp(soexpo)+pm$bbd
     sbexpo         = pm$SBEXPO+pm$FXSBSB*log(psb)+pm$FXSBCO*log(pco)+pm$FXSBWH*log(pwh)
     sbexpo         = exp(sbexpo)
return(c(corn,sbmeal,sboil,sbexpo,wheat))}