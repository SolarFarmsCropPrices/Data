function(amount,interestrate,lifetime){
     out       = (interestrate/((1+interestrate)^lifetime-1)+interestrate)*amount
     return(out)}