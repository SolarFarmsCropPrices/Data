function(p){
     cropprofit     = matrix(0,3105,6)
     cropprofit[,1] = p[1]*agmodel$YDCO-agmodel$FCCO
     cropprofit[,2] = p[2]*agmodel$YDSB-agmodel$FCSB
     cropprofit[,3] = p[5]*agmodel$YDWH-agmodel$FCWH
return(cropprofit)}