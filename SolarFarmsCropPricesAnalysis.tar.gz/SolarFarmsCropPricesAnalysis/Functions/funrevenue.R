function(p){
     cropprofit     = matrix(0,3105,3)
     area           = funarea(p)
     cropprofit[,1] = p[1]*agmodel$YDCO*area[,1]
     cropprofit[,2] = p[2]*agmodel$YDSB*area[,2]
     cropprofit[,3] = p[5]*agmodel$YDWH*area[,3]
     cropprofit     = rowSums(cropprofit)/rowSums(area)
return(cropprofit)}