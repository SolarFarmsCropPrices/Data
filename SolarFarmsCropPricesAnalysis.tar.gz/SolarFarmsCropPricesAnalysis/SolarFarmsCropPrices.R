#==================================================================================================
# Title:                 Solar Farms and Crop Prices
# Author:                Jerome Dumortier
# Date:                  19 May 2025
#==================================================================================================
rm(list=ls())
library(ggplot2)
library(ggpubr)
library(ggspatial)
library(openxlsx)
library(Rsolnp)
library(sf)
library(terra)
root                     = "D:/Research/Live Manuscripts/Solar Farms and Crop Prices"
dataxlsx                 = loadWorkbook(paste(root,"/Analysis/SolarFarmsCropPrices.xlsx",sep=""))
setwd(paste(root,"/Analysis",sep=""))
#--------------------------------------------------------------------------------------------------
# EIA Scenarios
#--------------------------------------------------------------------------------------------------
elecgenkwh               = readWorkbook(dataxlsx,sheet="ELECTRICITY GENERATION")
elecgenkwh               = subset(elecgenkwh,year %in% c(2025:2050))
ggplot(elecgenkwh,aes(x=year,y=value,color=aeocase))+geom_line()+ylim(0,2500)+
     scale_color_brewer(palette="Paired")+ylab("PV Electricity Generation (in TWh)")+theme_bw()+
     theme(legend.title=element_blank(),axis.title.x=element_blank(),panel.grid=element_blank())
ggsave(paste(root,"/Manuscript/aeocases.pdf",sep=""),width=6.5,height=2.75)
#--------------------------------------------------------------------------------------------------
# Calibration of the Agricultural Model: COST
#--------------------------------------------------------------------------------------------------
agmodel                  = readWorkbook(dataxlsx,sheet="COUNTY")
#--------------------------------------------------------------------------------------------------
usdacr                   = readWorkbook(dataxlsx,sheet="USDACR")
usdacr                   = aggregate(usdacr$value,FUN=mean,
                                     by=list(usdacr$commodity,usdacr$region,usdacr$item))
colnames(usdacr)         = c("commodity","region","item","value")
usdacr                   = aggregate(usdacr$value,FUN=sum,by=list(usdacr$commodity,usdacr$region))
colnames(usdacr)         = c("commodity","frrname","value")
#--------------------------------------------------------------------------------------------------
dffc                     = subset(usdacr,commodity=="Corn",select=c("frrname","value"))
dffc                     = merge(agmodel[c("fips","frrname")],dffc,by=c("frrname"),all=TRUE)
dffc$value[which(is.na(dffc$value))] = 0
dffc                     = dffc[c("fips","value")]
colnames(dffc)           = c("fips","FCCO")
agmodel                  = merge(agmodel,dffc,by=c("fips"))
#--------------------------------------------------------------------------------------------------
dffc                     = subset(usdacr,commodity=="Soybean",select=c("frrname","value"))
dffc                     = merge(agmodel[c("fips","frrname")],dffc,by=c("frrname"),all=TRUE)
dffc$value[which(is.na(dffc$value))] = 0
dffc                     = dffc[c("fips","value")]
colnames(dffc)           = c("fips","FCSB")
agmodel                  = merge(agmodel,dffc,by=c("fips"))
#--------------------------------------------------------------------------------------------------
dffc                     = subset(usdacr,commodity=="Wheat",select=c("frrname","value"))
dffc                     = merge(agmodel[c("fips","frrname")],dffc,by=c("frrname"),all=TRUE)
dffc$value[which(is.na(dffc$value))] = 0
dffc                     = dffc[c("fips","value")]
colnames(dffc)           = c("fips","FCWH")
agmodel                  = merge(agmodel,dffc,by=c("fips"))
rm(dffc,usdacr)
#--------------------------------------------------------------------------------------------------
# Calibration of the Agricultural Model: YIELD and AREA
#--------------------------------------------------------------------------------------------------
nassdata                 = readWorkbook(dataxlsx,sheet="NASS CROP DATA")
nassdata                 = aggregate(nassdata[c("ah","yd")],FUN=mean,
                                     by=list(nassdata$fips,nassdata$commodity))
colnames(nassdata)       = c("fips","commodity","area","yield")
#--------------------------------------------------------------------------------------------------
df                       = subset(nassdata,commodity=="CO",select=c("fips","area","yield"))
colnames(df)             = c("fips","AHCO","YDCO")
agmodel                  = merge(agmodel,df,by=c("fips"),all.x=TRUE)
agmodel$AHCO[which(is.na(agmodel$AHCO))] = 0
agmodel$YDCO[which(is.na(agmodel$YDCO))] = 0
#--------------------------------------------------------------------------------------------------
df                       = subset(nassdata,commodity=="SB",select=c("fips","area","yield"))
colnames(df)             = c("fips","AHSB","YDSB")
agmodel                  = merge(agmodel,df,by=c("fips"),all.x=TRUE)
agmodel$AHSB[which(is.na(agmodel$AHSB))] = 0
agmodel$YDSB[which(is.na(agmodel$YDSB))] = 0
#--------------------------------------------------------------------------------------------------
df                       = subset(nassdata,commodity=="WH",select=c("fips","area","yield"))
colnames(df)             = c("fips","AHWH","YDWH")
agmodel                  = merge(agmodel,df,by=c("fips"),all.x=TRUE)
agmodel$AHWH[which(is.na(agmodel$AHWH))] = 0
agmodel$YDWH[which(is.na(agmodel$YDWH))] = 0
#--------------------------------------------------------------------------------------------------
fc                       = c("FCCO","FCSB","FCWH")
ah                       = c("AHCO","AHSB","AHWH")
yd                       = c("YDCO","YDSB","YDWH")
agmodel                  = agmodel[c("fips","frr",fc,ah,yd)]
completeblock            = (agmodel[fc]>0)*(agmodel[ah]>0)*(agmodel[yd]>0)
agmodel[fc]              = agmodel[fc]*completeblock
agmodel[ah]              = agmodel[ah]*completeblock
agmodel[yd]              = agmodel[yd]*completeblock
completeblock            = cbind(agmodel[c("fips","frr")],completeblock)
commodities              = c("CO","SB","WH")
colnames(completeblock)  = c("fips","frr",commodities)
agmodel$maxarea          = rowSums(agmodel[paste("AH",commodities,sep="")])
maxarea                  = as.numeric(agmodel$maxarea)
rm(df,nassdata,ah,fc,yd)
#--------------------------------------------------------------------------------------------------
# Calibration of the Agricultural Model: AREA ELASTICITIES
#--------------------------------------------------------------------------------------------------
ahelastable              = readWorkbook(dataxlsx,sheet="AH ELASTICITY")
ahelas                   = list()
#--------------------------------------------------------------------------------------------------
for(i in commodities){
     temp                = subset(ahelastable,commodity==i,select=c("frr",commodities))
     temp                = merge(completeblock[c("fips","frr")],temp,by=c("frr"),all.x=TRUE)
     temp[is.na(temp)]   = 0
     ahelas[[i]]         = temp[,3:5]*completeblock[,3:5]}
#--------------------------------------------------------------------------------------------------
rm(ahelastable,temp,i)
#--------------------------------------------------------------------------------------------------
# Loading Parameters
#--------------------------------------------------------------------------------------------------
pm                       = (readWorkbook(dataxlsx,sheet="PM"))[c("name","value")]
pmnames                  = pm$name
pm                       = t(as.numeric(pm$value))
colnames(pm)             = pmnames
pm                       = as.data.frame(pm)
rm(pmnames)
#--------------------------------------------------------------------------------------------------
# Calibration of the Agricultural Model: AREA CONSTANT
#--------------------------------------------------------------------------------------------------
funreturn                = dget(paste(root,"/Analysis/Functions/funreturn.R",sep=""))
funarea                  = dget(paste(root,"/Analysis/Functions/funarea.R",sep=""))
pm$ethanol               = 135
areacons                 = matrix(0,3105,3)
agdata                   = readWorkbook(dataxlsx,"CROP DEMAND")
p                        = agdata[c("pco","psb","psm","pso","pwh")]
p                        = as.numeric(colMeans(p))
returns                  = funreturn(p)
#--------------------------------------------------------------------------------------------------
for (i in 1:3){
     df                       = agmodel[paste("AH",commodities[i],sep="")]
     df                       = df[1:3105,1]
     elas                     = ahelas[[commodities[i]]]
     elas                     = as.matrix(returns^elas)
     elas[is.infinite(elas)]  = 1
     elas                     = apply(elas,1,prod)
     areacons[,i]             = df/elas}
areacons[is.na(areacons)]= 0
#--------------------------------------------------------------------------------------------------
funproduction            = dget(paste(root,"/Analysis/Functions/funproduction.R",sep=""))
qs                       = funproduction(p)
rm(completeblock,returns,commodities,df,elas,i)
#--------------------------------------------------------------------------------------------------
# Calibration of the Agricultural Model: DEMAND
#--------------------------------------------------------------------------------------------------
rad                      = colMeans(agdata) # recent ag data
pm$pop                   = 335
pm$gcau                  = 99
pm$hpau                  = 154
pm$bbd                   = rad[15]
#--------------------------------------------------------------------------------------------------
# Crop Demand Calibration: Corn
#--------------------------------------------------------------------------------------------------
total                    = rad[["co_food"]]+rad[["co_feed"]]+rad[["co_expo"]]
co_food                  = (rad[["co_food"]]/total)*(qs[1]-pm$ethanol)
co_feed                  = (rad[["co_feed"]]/total)*(qs[1]-pm$ethanol)
co_expo                  = (rad[["co_expo"]]/total)*(qs[1]-pm$ethanol)
#--------------------------------------------------------------------------------------------------
pm$COFOOD                = log(co_food/pm$pop)-pm$FOCOCO*log(p[1])
pm$COFEED                = log(co_feed/pm$gcau)-pm$FECOCO*log(p[1])-pm$FECOSB*log(p[2])
pm$COEXPO                = log(co_expo)-pm$FXCOCO*log(p[1])-pm$FXCOWH*log(p[5])
#--------------------------------------------------------------------------------------------------
# Crop Demand Calibration: Wheat
#--------------------------------------------------------------------------------------------------
total                    = rad[["wh_food"]]+rad[["wh_feed"]]+rad[["wh_expo"]]
wh_food                  = (rad[["wh_food"]]/total)*qs[3]
wh_feed                  = (rad[["wh_feed"]]/total)*qs[3]
wh_expo                  = (rad[["wh_expo"]]/total)*qs[3]
#--------------------------------------------------------------------------------------------------
pm$WHFOOD                = log(wh_food/pm$pop)-pm$FOWHWH*log(p[5])
pm$WHFEED                = log(wh_feed/pm$gcau)-pm$FEWHWH*log(p[5])-pm$FEWHCO*log(p[1])
pm$WHEXPO                = log(wh_expo)-pm$FXWHSB*log(p[2])-pm$FXWHCO*log(p[1])-pm$FXWHWH*log(p[5])
#--------------------------------------------------------------------------------------------------
# Crop Demand Calibration: Soybeans
#--------------------------------------------------------------------------------------------------
total                    = rad[["sb_crsh"]]+rad[["sb_expo"]]
sb_crsh                  = (rad[["sb_crsh"]]/total)*qs[2]
sb_expo                  = (rad[["sb_expo"]]/total)*qs[2]
#--------------------------------------------------------------------------------------------------
pm$SBEXPO                = log(sb_expo)-pm$FXSBSB*log(p[2])-pm$FXSBCO*log(p[1])-pm$FXSBWH*log(p[5])
#--------------------------------------------------------------------------------------------------
# Crop Demand Calibration: Soybean Meal
#--------------------------------------------------------------------------------------------------
total                    = 44/60*sb_crsh
sm_feed                  = (rad[["sm_feed"]]/(rad[["sm_feed"]]+rad[["sm_expo"]]))*total
sm_expo                  = (rad[["sm_expo"]]/(rad[["sm_feed"]]+rad[["sm_expo"]]))*total
#--------------------------------------------------------------------------------------------------
pm$SMFEED                = log(sm_feed/pm$hpau)-pm$FESMSM*log(p[3])-pm$FESMCO*log(p[1])
pm$SMEXPO                = log(sm_expo)-pm$FXSMSM*log(p[3])
#--------------------------------------------------------------------------------------------------
# Crop Demand Calibration: Soybean Oil
#--------------------------------------------------------------------------------------------------
total                    = 11/60*sb_crsh
so_food                  = (rad[["so_food"]]/(rad[["so_food"]]+rad[["so_expo"]]+pm$bbd))*total
so_expo                  = (rad[["so_expo"]]/(rad[["so_food"]]+rad[["so_expo"]]+pm$bbd))*total
so_bbd                   = (pm$bbd/(rad[["so_food"]]+rad[["so_expo"]]+pm$bbd))*total
pm$bbd                   = so_bbd
#--------------------------------------------------------------------------------------------------
pm$SOFOOD                = log(so_food/pm$pop)-pm$FOSOSO*log(p[4])
pm$SOEXPO                = log(so_expo)-pm$FXSOSO*log(p[4])
#--------------------------------------------------------------------------------------------------
rm(total,co_food,co_feed,co_expo,sb_crsh,sb_expo,sm_feed,sm_expo,so_food,so_expo,so_bbd,
   wh_food,wh_feed,wh_expo,rad,agdata,qs)
#--------------------------------------------------------------------------------------------------
fundemand                = dget(paste(root,"/Analysis/Functions/fundemand.R",sep=""))
funexdemand              = dget(paste(root,"/Analysis/Functions/funexdemand.R",sep=""))
#--------------------------------------------------------------------------------------------------
# Land Requirement
#--------------------------------------------------------------------------------------------------
uspvdb                   = readWorkbook(dataxlsx,sheet="USPVDB")
axis                     = c("dual-axis","single-axis","fixed-tilt")
uspvdb                   = subset(uspvdb,ptype=="greenfield" & pagrivolt=="non-agrivoltaic" &
                                         pzscore<=1.96 & pzscore>=-1.96 &
                                         paxis %in% axis)
uspvdb$parea             = uspvdb$parea/10000
bhat                     = lm(parea~pcapac,data=uspvdb)
landreq                  = bhat$coefficients[2]             # Land requirement in hectares per MW
#--------------------------------------------------------------------------------------------------
# AC/DC Conversion and Cost in 2022 (see section Least-Cost Siting in Paper)
#--------------------------------------------------------------------------------------------------
uspvdb$convertereff      = uspvdb$pcapac/uspvdb$pcapdc
uspvdb                   = subset(uspvdb,pcapac>20 & convertereff<1)
capex2022                = 1068/mean(uspvdb$convertereff) 
rm(axis,bhat,uspvdb,capex2022,elecgenkwh,landreq,maxarea)
#--------------------------------------------------------------------------------------------------
# Loading County and State GIS Maps
#--------------------------------------------------------------------------------------------------
counties                 = read_sf(dsn=paste(root,"/GIS/Census",sep=""),layer="counties")
states                   = read_sf(dsn=paste(root,"/GIS/Census",sep=""),layer="states")
#--------------------------------------------------------------------------------------------------
# Calculating PV Power Potential
#--------------------------------------------------------------------------------------------------
pvout                    = rast(paste(root,"/GIS/Solar Atlas/PVOUT.tif",sep=""))
pvout                    = extract(pvout,counties,"mean",na.rm=TRUE)
pvout$fips               = counties$fips
pvout                    = pvout[c("fips","PVOUT")]
#--------------------------------------------------------------------------------------------------
tempcounties             = counties
tempcounties             = merge(tempcounties,pvout,by=c("fips"))
labels                   = c("Below 1200","1200-1300","1300-1400","1400-1500","1500-1600",
                             "1600-1700","1700-1800","Above 1800")
breaks                   = c(1000,1200,1300,1400,1500,1600,1700,1800,2000)
ggplot()+
     geom_sf(data=tempcounties,aes(fill=cut(PVOUT,breaks=breaks,include.lowest=TRUE)),linetype=0)+
     theme_bw()+scale_fill_brewer(type="qual",labels=labels,palette="YlOrRd",direction=1)+
     geom_sf(data=states,colour="black",linetype=1,alpha=0)+coord_sf(crs="+init=epsg:26978")+
     guides(fill=guide_legend(title="kWh/kWp"))
ggsave(paste(root,"/Versions/Presentation/pvoutmap.pdf",sep=""),width=7,height=4)
#--------------------------------------------------------------------------------------------------
cashrent                 = readWorkbook(dataxlsx,sheet="CASH RENT")
gdpdef                   = readWorkbook(dataxlsx,sheet="GDPDEF")
gdpdef$value             = gdpdef$value[which(gdpdef$year==2023)]/gdpdef$value
cashrent                 = merge(cashrent,gdpdef,by=c("year"))
cashrent$value           = cashrent$value.x*cashrent$value.y
cashrent                 = subset(cashrent,year>=2019)
cashrent                 = aggregate(cashrent$value,FUN=mean,by=list(cashrent$fips))
colnames(cashrent)       = c("fips","value")
rm(gdpdef)
#--------------------------------------------------------------------------------------------------
cashrent                 = merge(agmodel[c("fips","maxarea")],cashrent,by=c("fips"),all.x=TRUE)
cashrent                 = merge(cashrent,pvout,by=c("fips"),all.x=TRUE)
colnames(cashrent)       = c("fips","maxarea","cashrent","pvout")
#--------------------------------------------------------------------------------------------------
cashrent$cashrent[which(cashrent$maxarea==0)]     = 0
cashrent$pvout[which(cashrent$maxarea==0)]        = 0
cashrent$cashrent[is.na(cashrent$cashrent)]       = 0
cashrent$pvout[which(cashrent$cashrent==0)]       = 0
#--------------------------------------------------------------------------------------------------
funaf                    = dget(paste(root,"/Analysis/Functions/funaf.R",sep=""))
electricityproduction    = 1 # (in MWh)
scenarios                = readWorkbook(dataxlsx,sheet="SCENARIOS")
lcoe                     = merge(cashrent,scenarios)
rm(cashrent,pvout)
#--------------------------------------------------------------------------------------------------
lcoe$kwinstalled         = ifelse(lcoe$pvout>0,electricityproduction/(lcoe$pvout/1000),0)
lcoe$capex               = lcoe$kwinstalled*lcoe$capex
lcoe$capex               = funaf(lcoe$capex,0.05,20)
lcoe$omcost              = lcoe$kwinstalled*lcoe$omcost
lcoe$landcost            = lcoe$kwinstalled*(lcoe$landreq/1000)*lcoe$cashrent
lcoe$costpermwh          = lcoe$capex+lcoe$omcost+lcoe$landcost
lcoe$landcostshare       = ifelse(lcoe$costpermwh>0,lcoe$landcost/lcoe$costpermwh,0)
lcoe$mwhperha            = ifelse(lcoe$landreq>0,lcoe$pvout/lcoe$landreq,0)
lcoe$twh                 = lcoe$maxarea*lcoe$countycap*lcoe$mwhperha/1000000
#--------------------------------------------------------------------------------------------------
temp      = data.frame(scenario=c("Baseline (10%) - 100% Cropland",
                                  "Baseline (Low Cost, 10%) - 100% Cropland",
                                  "Baseline (High Land, 10%) - 100% Cropland",
                                  "Baseline (High Land, Low Cost, 10%) - 100% Cropland"),
                                      sname=c("Baseline","Low Cost","High Land",
                                              "High Land, Low Cost"))
df                       = subset(lcoe,landcostshare>0 & scenario %in% temp$scenario)
df                       = merge(df,temp,by=c("scenario"))
df$landcostshare         = df$landcostshare*100
ggdensity(df,x="landcostshare",add="median",color="sname",fill="sname",palette="jco")+
     theme(legend.title=element_blank())+xlab("Share of Land Cost (%)")+ylab("Density")
ggsave(paste(root,"/Manuscript/landcostshare.pdf",sep=""),width=10,height=5)
rm(df,temp)
#--------------------------------------------------------------------------------------------------
lcoe                     = lcoe[c("fips","maxarea","scenarioid","elecgentwh","countycap",
                                  "costpermwh","twh")]
#--------------------------------------------------------------------------------------------------
lcoelist                 = list()
for(i in 1:nrow(scenarios)){
     temp                     = subset(lcoe,scenarioid==scenarios$scenarioid[i])
     temp                     = temp[order(temp$costpermwh),]
     row.names(temp)          = NULL
     temp$cumtwh              = cumsum(temp$twh)
     temp$solararea           = ifelse(temp$cumtwh>temp$elecgentwh | temp$twh==0,0,
                                       temp$countycap*temp$maxarea)
     rowid                    = max(which(temp$cumtwh<temp$elecgentwh))
     missingproduction        = temp$elecgentwh[rowid]-temp$cumtwh[rowid]
     areashare                = missingproduction/temp$twh[rowid+1]
     temp$solararea[rowid+1]  = areashare*temp$countycap[rowid+1]*temp$maxarea[rowid+1]
     lcoelist[[i]]            = temp}
lcoelist                 = do.call("rbind",lcoelist)
rm(temp,rowid,missingproduction,areashare)
#--------------------------------------------------------------------------------------------------
# Establishing Baseline with No Solar Farms
#--------------------------------------------------------------------------------------------------
funrevenue               = dget(paste(root,"/Analysis/Functions/funrevenue.R",sep=""))
maxarea                  = as.numeric(agmodel$maxarea)
output                   = solnp(p,funexdemand,LB=0.5*p,UB=1.75*p)
p                        = output$pars
prices                   = data.frame(commodity=c("CO","SB","SM","SO","WH"),
                                      value=p,scenario="Baseline")
production               = data.frame(commodity=c("CO","SB","WH"),
                                      value=funproduction(p),scenario="Baseline")
area                     = data.frame(fips=agmodel$fips,value=rowSums(funarea(p)),
                                      scenario="Baseline")
farmrevenue              = data.frame(fips=agmodel$fips,value=funrevenue(p),
                                      scenario="Baseline")
#--------------------------------------------------------------------------------------------------
# Looping through the scenarios
#--------------------------------------------------------------------------------------------------
priceslist               = list()
productionlist           = list()
arealist                 = list()
farmrevlist              = list()
#--------------------------------------------------------------------------------------------------
for(i in 1:nrow(scenarios)){
     maxarea             = subset(lcoelist,scenarioid==scenarios$scenarioid[i])
     maxarea             = maxarea[order(maxarea$fips),]
     maxarea             = as.numeric(maxarea$maxarea-maxarea$solararea)
     output              = solnp(p,funexdemand,LB=0.5*p,UB=1.75*p)
     priceslist[[i]]     = data.frame(commodity=c("CO","SB","SM","SO","WH"),
                                      value=output$pars,scenario=scenarios$scenario[i])
     productionlist[[i]] = data.frame(commodity=c("CO","SB","WH"),
                                      value=funproduction(output$pars),
                                      scenario=scenarios$scenario[i])
     arealist[[i]]       = data.frame(fips=agmodel$fips,value=rowSums(funarea(output$pars)),
                                      scenario=scenarios$scenario[i])
     farmrevlist[[i]]    = data.frame(fips=agmodel$fips,value=funrevenue(output$pars),
                                      scenario=scenarios$scenario[i])}
#--------------------------------------------------------------------------------------------------
priceslist               = do.call("rbind",priceslist)
prices                   = rbind(priceslist,prices)
productionlist           = do.call("rbind",productionlist)
production               = rbind(productionlist,production)
arealist                 = do.call("rbind",arealist)
area                     = rbind(arealist,area)
farmrevlist              = do.call("rbind",farmrevlist)
farmrevenue              = rbind(farmrevlist,farmrevenue)
#--------------------------------------------------------------------------------------------------
rm(list=setdiff(ls(),c("prices","production","area","farmrevenue")))
save.image("SolarFarmsCropPricesResults.RData")
#==================================================================================================
# End of File
#==================================================================================================